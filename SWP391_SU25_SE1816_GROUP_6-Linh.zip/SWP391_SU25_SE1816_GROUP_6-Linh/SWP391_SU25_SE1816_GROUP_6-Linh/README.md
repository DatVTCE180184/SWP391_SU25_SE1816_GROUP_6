Smartphone Retail Management System
